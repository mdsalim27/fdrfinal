import React from 'react'

const Page = () => {
  return (
    <div>
             <h1 className='text-blue-600 font-extralight text-[40px] text-center bg-black py-10'>Pages</h1>
           
    </div>
  )
}

export default Page
