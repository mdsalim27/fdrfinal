import React from 'react'
import  letest from '../assets/letest.png'
const GetLeates = () => {
  return (
    <div className='mx-auto lg:my-20 mt-10 lg:mt-0 cursor-pointer '>
      <img className='w-full' src={letest} alt="" />
    </div>
  )
}

export default GetLeates
